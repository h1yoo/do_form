휴가신청서 > DefaultVacationEhrIntegrationHalfVerEn

approval/daouform/vacation_half_ver/vacation-sample_en

/opt/TerraceTims/web/webmail/webapps/ROOT/resources/dist/js/plugins/approval/daouform/vacation_half_ver/templates/halfTemplate_en.html

/opt/TerraceTims/web/webmail/webapps/ROOT/resources/dist/js/plugins/approval/daouform/vacation_half_ver/templates/pointTemplate_en.html

/opt/TerraceTims/web/webmail/webapps/ROOT/resources/dist/js/plugins/approval/daouform/vacation_half_ver/templates/typeTemplate_en.html

/opt/TerraceTims/web/webmail/webapps/ROOT/resources/dist/js/plugins/approval/daouform/vacation_half_ver/views/main_en.js

/opt/TerraceTims/web/webmail/webapps/ROOT/resources/dist/js/plugins/approval/daouform/vacation_half_ver/vacation-sample_en.js